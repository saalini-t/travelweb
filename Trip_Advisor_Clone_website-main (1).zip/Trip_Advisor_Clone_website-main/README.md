
# TripAdvisor_clone

This project is a team project of 5 members, Trip Advisor is an online traveling and hotel booking website. We built this cloning project
Within 5 days and this is our first project during the Masai curriculum 
[Trip Advisor Website](https://glittering-zabaione-8fa013.netlify.app/)

## Features

- Login/signup
- productAdding to wishlist
- add cart
- filtering
- sorting
- payment checkout



## Installation

- copy this https://github.com/sunnylalwani41/Trip_Advisor_Clone_website.git
- Select path where you want to store the project in your pc
- open the corresponding file / folder with editor
- open terminal of your editor
- use  --> git clone (paste link) <-- 
- after project cloned to your folder
- go to index.html inside Trip_Advisor_Clone_website folder
- open with live server
    
## Tech Stack

* Javascript
* HTML
* CSS



# Screenshots
## Landing Page
<img src="./WebsiteScreenShot/Trip Advisor_LandingPage.PNG">

## Product Page
<img src="./WebsiteScreenShot/Trip Advisor_Menu.PNG" border="5px solid black">

## Basket Page
<img src="WebsiteScreenShot/Trip Advisor_Basket.PNG">
